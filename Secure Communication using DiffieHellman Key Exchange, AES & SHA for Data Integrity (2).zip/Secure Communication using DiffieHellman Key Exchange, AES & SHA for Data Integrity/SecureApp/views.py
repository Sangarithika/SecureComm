from django.shortcuts import render
from django.template import RequestContext
from django.contrib import messages
from django.http import HttpResponse
import os
from django.core.files.storage import FileSystemStorage
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
import pymysql
import codecs
import random
import pyaes, pbkdf2, binascii, os, secrets
import base64
import hashlib
import datetime
import codecs, base64, hashlib, datetime, pymysql

global uname, filename, shared_key

space0 = "​"
space1 = "‌"

def hide(text,message):
    message = "".join(format(ord(i),"08b") for i in str(message))
    midpoint = int((len(text)/2)//1)
    result = ""
    for i in list(str(message)):
        result += space0 if i == "0" else space1 if i == "1" else ""
    return text[:midpoint]+result+text[midpoint:]

def show(text):
    result = ""
    for i in list(str(text)):
        if i == space0:
            result += "0"
        elif i == space1:
            result += "1"
    result = "".join([chr(int(result[i:i+8],2)) for i in range(0,len(result),8)])
    if result == "":
        result = None
    return result

def getDiffieKey():#function to get common secret key between two users as shared1 and shared2
    P = 23
    G = 9
    x1 = random.randint(10,100)
    x2 = random.randint(10,100)
    y1, y2 = pow(G, x1) % P, pow(G, x2) % P
    share1, share2 = pow(y2, x1) % P, pow(y1, x2) % P
    return share1

def getKey(diffie_key): #generating AES key based on Diffie common secret shared key
    password = "s3cr3t*c0d3"
    passwordSalt = str(diffie_key)#get AES key using diffie
    key = pbkdf2.PBKDF2(password, passwordSalt).read(32)
    return key

def encrypt(plaintext, key): #AES data encryption
    aes = pyaes.AESModeOfOperationCTR(getKey(key), pyaes.Counter(31129547035000047302952433967654195398124239844566322884172163637846056248223))
    ciphertext = aes.encrypt(plaintext)
    return ciphertext

def decrypt(enc, key): #AES data decryption
    aes = pyaes.AESModeOfOperationCTR(getKey(key), pyaes.Counter(31129547035000047302952433967654195398124239844566322884172163637846056248223))
    decrypted = aes.decrypt(enc)
    return decrypted


def UploadAction(request):
    if request.method == 'POST':
        global uname
        username = request.user.username
        uname = username
        receiver = request.POST.get('receiver')
        uploaded_file = request.FILES.get('t1')

        if not uploaded_file:
            return render(request, 'UploadFile.html', {'data': 'No file uploaded.'})

        # Add timestamp to filename to avoid overwrite
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        file_name = f"{timestamp}_{uploaded_file.name}"

        try:
            file_data = uploaded_file.read().decode('utf-8')  # Safe decode
        except Exception:
            return render(request, 'UploadFile.html', {'data': 'File decoding failed. Please upload a valid UTF-8 text file.'})

        # Encrypt and hide key
        diffie_key = getDiffieKey()
        encrypted_data = encrypt(file_data, diffie_key)
        encrypted_data = base64.b64encode(encrypted_data).decode()
        hidden = hide(encrypted_data, diffie_key)

        # Save encrypted file
        with open('SecureApp/static/files/' + file_name, "wb") as file:
            file.write(hidden.encode())

        # Hash the actual written data
        hashcode = hashlib.sha1(hidden.encode()).hexdigest()

        # Prepare output
        output = f"{file_name} encrypted using Diffie shared key & AES : {diffie_key}<br/>"
        output += "Diffie Key hidden inside encrypted File<br/>"
        output += f"Data Integrity will be checked with Hashcode = {hashcode}"

        # Save metadata to DB
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            db_connection = pymysql.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='root',
                database='secureapp',
                charset='utf8'
            )
            db_cursor = db_connection.cursor()
            sql_query = """
                INSERT INTO files (owner, receiver, filename, hashcode, upload_date)
                VALUES (%s, %s, %s, %s, %s)
            """
            db_cursor.execute(sql_query, (uname, receiver, file_name, hashcode, now))
            db_connection.commit()
        except Exception as e:
            output += f"<br/><br/>DB Error: {str(e)}"

        return render(request, 'UploadFile.html', {'data': output})


def DownloadFileAction(request):
    if request.method == 'GET':
        global uname
        filename = request.GET['t1']
        key = request.GET['t2']
        with open('SecureApp/static/files/'+filename, "rb") as file:
            filedata = file.read()
        file.close()
        filedata = base64.b64decode(filedata)
        dec = decrypt(filedata, key)
        response = HttpResponse(dec, content_type="application/octet-stream")
        response['Content-Disposition'] = "attachment; filename=%s" % filename
        return response

def getHashcode(filename):
    hashcode = None
    con = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'secureapp',charset='utf8')
    with con:
        cur = con.cursor()
        cur.execute("select hashcode FROM files where filename='"+filename+"'")
        rows = cur.fetchall()
        for row in rows:
            hashcode = row[0]
            break
    return hashcode

def FileIntegrityAction(request):
    if request.method == 'GET':
        filename = request.GET.get('t1')
        original_hashcode = request.GET.get('t2')

        if not filename or not original_hashcode:
            return render(request, 'UserScreen.html', {'data': 'Invalid request parameters.'})

        file_path = f'SecureApp/static/files/{filename}'

        if not os.path.exists(file_path):
            return render(request, 'UserScreen.html', {'data': f'File "{filename}" not found on server.'})

        try:
            with open(file_path, "rb") as file:
                filedata = file.read()

            # ✅ Generate SHA1 hash on current file
            generated_hashcode = hashlib.sha1(filedata).hexdigest()

            if original_hashcode == generated_hashcode:
                output = "✅ File Integrity Successful. No Data Changed."
            else:
                output = "❌ File Integrity Failed. Data Was Modified."

        except Exception as e:
            output = f"Error reading or hashing file: {str(e)}"

        return render(request, 'UserScreen.html', {'data': output})
   

def FileIntegrity(request):
    global uname
    if request.method == 'GET':
        output = '<h2>File Integrity Status</h2>'
        output += '<table border=1 align=center width=100%>'
        font = '<font size="" color="black">'
        arr = ['Filename', 'Extracted Hidden Diffie Shared Key', 'File Integrity Hashcode', 'Check File Integrity', 'Your Role']
        output += "<tr>" + "".join([f"<th>{font}{a}</th>" for a in arr]) + "</tr>"

        try:
            con = pymysql.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='root',
                database='secureapp',
                charset='utf8'
            )
            with con:
                cur = con.cursor()
                # ✅ Fetch files where user is either sender or receiver
                cur.execute("SELECT filename, owner, receiver FROM files WHERE owner=%s OR receiver=%s", (uname, uname))
                file_rows = cur.fetchall()

            if not file_rows:
                output += f"<tr><td colspan='5'><center>{font}No files available</center></td></tr>"

            for row in file_rows:
                filename, owner, receiver = row
                role = "Sender" if uname == owner else "Receiver"
                file_path = f"SecureApp/static/files/{filename}"

                if os.path.exists(file_path):
                    with open(file_path, "rb") as file:
                        hidden = file.read()

                    try:
                        showing = show(hidden.decode())
                    except Exception:
                        showing = "Invalid"

                    hashcode = getHashcode(filename) or "Hashcode Not Available"
                    output += f"<tr><td>{font}{filename}</td>"
                    output += f"<td>{font}{showing}{random.randint(1000,9999)}</td>"
                    output += f"<td>{font}{hashcode}</td>"
                    output += f'<td><a href="FileIntegrityAction?t1={filename}&t2={hashcode}">{font}Click Here</a></td>'
                    output += f"<td>{font}{role}</td></tr>"
                else:
                    output += f"<tr><td colspan='5'>{font}File not found: {filename}</td></tr>"

        except Exception as e:
            output += f"<tr><td colspan='5'>{font}Error: {e}</td></tr>"

        output += "</table>"
        return render(request, 'UserScreen.html', {'data': output})

        


def DownloadFile(request):
    global uname
    if request.method == 'GET':
        output = ''
        font = '<font size="" color="black">'
        # output += '<h2>Available Encrypted Files</h2>'
        output += '<table border=1 align=center width=100%>'
        arr = ['Filename', 'Extracted Hidden Diffie Shared Key', 'File Integrity Hashcode', 'Download', 'Your Role']
        output += "<tr>" + "".join([f"<th>{font}{a}</th>" for a in arr]) + "</tr>"

        try:
            con = pymysql.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='root',
                database='secureapp',
                charset='utf8'
            )
            with con:
                cur = con.cursor()
                cur.execute("SELECT filename, owner, receiver, hashcode FROM files WHERE owner=%s OR receiver=%s", (uname, uname))
                rows = cur.fetchall()

            if not rows:
                output += f"<tr><td colspan='5'><center>{font}No files available</center></td></tr>"

            for row in rows:
                filename, owner, receiver, hashcode = row
                role = "Sender" if uname == owner else "Receiver"
                filepath = f"SecureApp/static/files/{filename}"

                if os.path.exists(filepath):
                    with open(filepath, "rb") as file:
                        hidden = file.read()

                    try:
                        showing = show(hidden.decode())
                    except Exception:
                        showing = "Invalid"

                    output += f"<tr><td>{font}{filename}</td>"
                    output += f"<td>{font}{showing}{random.randint(1000,9999)}</td>"
                    output += f"<td>{font}{hashcode}</td>"
                    output += f'<td><a href="DownloadFileAction?t1={filename}&t2={showing}">{font}Click Here</a></td>'
                    output += f"<td>{font}{role}</td></tr>"
                else:
                    output += f"<tr><td colspan='5'>{font}File not found: {filename}</td></tr>"

        except Exception as e:
            output += f"<tr><td colspan='5'>{font}Error: {e}</td></tr>"

        output += "</table>"
        return render(request, 'UserScreen.html', {'data': output})



def UploadFile(request):
    if request.method == 'GET':
        global uname
        users = []

        # Fetch usernames from the signup table (excluding the current user)
        con = pymysql.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='root',
            database='secureapp',
            charset='utf8'
        )
        with con:
            cur = con.cursor()
            cur.execute("SELECT username FROM signup WHERE username != %s", (uname,))
            rows = cur.fetchall()
            for row in rows:
                users.append(row[0])  # row[0] = username

        return render(request, 'UploadFile.html', {'users': users})

def UserLogin(request):
    if request.method == 'GET':
       return render(request, 'UserLogin.html', {})  

def index(request):
    if request.method == 'GET':
       return render(request, 'index.html', {})

def Signup(request):
    if request.method == 'GET':
       return render(request, 'Signup.html', {})

def UserLoginAction(request):
    global uname
    if request.method == 'POST':
        username = request.POST.get('t1', False)
        password = request.POST.get('t2', False)
        index = 0
        con = pymysql.connect(host='127.0.0.1',port = 3306,user = 'root', password = 'root', database = 'secureapp',charset='utf8')
        with con:
            cur = con.cursor()
            cur.execute("select username,password FROM signup")
            rows = cur.fetchall()
            for row in rows:
                if row[0] == username and password == row[1]:
                    uname = username
                    index = 1
                    break		
        if index == 1:
            context= {'data':'welcome '+uname}
            return render(request, 'UserScreen.html', context)
        else:
            context= {'data':'login failed'}
            return render(request, 'UserLogin.html', context)        

from django.shortcuts import render, redirect
from django.contrib import messages  # <-- Add this
import pymysql

def SignupAction(request):
    if request.method == 'POST':
        username = request.POST.get('t1', '').strip()
        password = request.POST.get('t2', '').strip()
        contact = request.POST.get('t3', '').strip()
        gender = request.POST.get('t4', '').strip()
        email = request.POST.get('t5', '').strip()
        address = request.POST.get('t6', '').strip()
        output = ""

        con = pymysql.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='root',
            database='secureapp',
            charset='utf8'
        )
        with con:
            cur = con.cursor()
            cur.execute("SELECT username FROM signup WHERE username=%s", (username,))
            row = cur.fetchone()
            if row:
                output = f"{username} already exists"
                return render(request, 'Signup.html', {'data': output})

        try:
            db_connection = pymysql.connect(
                host='127.0.0.1',
                port=3306,
                user='root',
                password='root',
                database='secureapp',
                charset='utf8'
            )
            db_cursor = db_connection.cursor()
            insert_query = """
                INSERT INTO signup(username, password, contact_no, gender, email, address)
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            db_cursor.execute(insert_query, (username, password, contact, gender, email, address))
            db_connection.commit()

            if db_cursor.rowcount == 1:
                messages.success(request, "Signup successful! Please login.")
                return redirect('UserLogin')  # Redirect to login page

        except Exception as e:
            output = f"Database error: {e}"
            return render(request, 'Signup.html', {'data': output})

    return render(request, 'Signup.html', {'data': 'Invalid request'})
