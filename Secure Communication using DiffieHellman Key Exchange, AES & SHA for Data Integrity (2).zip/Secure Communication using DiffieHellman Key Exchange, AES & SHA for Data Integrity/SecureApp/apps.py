from django.apps import AppConfig


class SecureappConfig(AppConfig):
    name = 'SecureApp'
